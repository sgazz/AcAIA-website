import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "AcAIA - AI Asistent za Učenje i Razvoj",
  description: "Revolucionarni AI asistent koji transformiše način učenja. Od chat-a do generisanja problema, od simulacija ispita do karijernog vođenja.",
  keywords: "AI, učenje, obrazovanje, chat, problemi, ispiti, karijera",
  authors: [{ name: "AcAIA Team" }],
  openGraph: {
    title: "AcAIA - AI Asistent za Učenje i Razvoj",
    description: "Revolucionarni AI asistent koji transformiše način učenja.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="sr" className="scroll-smooth">
      <body className={inter.className}>
        <div className="min-h-screen flex flex-col">
          <Navbar />
          <main className="flex-1">
            {children}
          </main>
          <Footer />
        </div>
      </body>
    </html>
  );
}

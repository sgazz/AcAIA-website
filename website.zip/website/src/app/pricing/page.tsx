import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Check, Star, Zap, Crown } from "lucide-react";
import Link from "next/link";

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      {/* Header */}
      <section className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-8">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Nazad na početnu
          </Link>
          
          <div className="text-center">
            <Badge variant="secondary" className="mb-4">
              Cene
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
              Jednostavne i
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {" "}Transparentne Cene
              </span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              Izaberite plan koji najbolje odgovara vašim potrebama. 
              Svi planovi uključuju besplatnu probnu verziju.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Free Plan */}
            <Card className="group hover:shadow-xl transition-all duration-300 border-0 bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-gradient-to-r from-gray-500 to-gray-600 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Star className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-2xl">Besplatno</CardTitle>
                <div className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                  €0
                  <span className="text-lg font-normal text-gray-600 dark:text-gray-300">/mesečno</span>
                </div>
                <CardDescription>
                  Savršeno za početnike koji žele da isprobaju platformu
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>5 AI chat poruka dnevno</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>3 generisana problema</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Osnovna analitika</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Email podrška</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">
                  Započnite Besplatno
                </Button>
              </CardContent>
            </Card>

            {/* Pro Plan */}
            <Card className="group hover:shadow-xl transition-all duration-300 border-2 border-blue-500 bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-blue-600 text-white">
                  Najpopularniji
                </Badge>
              </div>
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-2xl">Pro</CardTitle>
                <div className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                  €19
                  <span className="text-lg font-normal text-gray-600 dark:text-gray-300">/mesečno</span>
                </div>
                <CardDescription>
                  Za aktivne učenike koji žele napredne funkcije
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Neograničeno AI chat poruka</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>50 generisanih problema</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Napredna analitika</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Simulacije ispita</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Karijerno vođenje</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Prioritetna podrška</span>
                  </li>
                </ul>
                <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                  Započnite Pro
                </Button>
              </CardContent>
            </Card>

            {/* Enterprise Plan */}
            <Card className="group hover:shadow-xl transition-all duration-300 border-0 bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Crown className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-2xl">Enterprise</CardTitle>
                <div className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                  €49
                  <span className="text-lg font-normal text-gray-600 dark:text-gray-300">/mesečno</span>
                </div>
                <CardDescription>
                  Za institucije i timove koji žele sve funkcije
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Sve iz Pro plana</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Neograničeno generisanje</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Tim upravljanje</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>API pristup</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Dedicated podrška</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span>Custom integracije</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">
                  Kontaktirajte Nas
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white dark:bg-slate-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Često Postavljena Pitanja
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Odgovori na najčešća pitanja o našim cenama
            </p>
          </div>

          <div className="space-y-8">
            <Card className="border-0 bg-gray-50 dark:bg-slate-700">
              <CardHeader>
                <CardTitle>Da li mogu da promenim plan?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300">
                  Da, možete da promenite plan u bilo kom trenutku. Promene se primenjuju odmah.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 bg-gray-50 dark:bg-slate-700">
              <CardHeader>
                <CardTitle>Da li postoji besplatna probna verzija?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300">
                  Da, svi planovi uključuju 14-dnevnu besplatnu probnu verziju.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 bg-gray-50 dark:bg-slate-700">
              <CardHeader>
                <CardTitle>Kako funkcioniše otkazivanje?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300">
                  Možete da otkažete pretplatu u bilo kom trenutku. Nastavićete da imate pristup do kraja perioda naplate.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Spreman da započneš?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Pridruži se hiljadama korisnika koji već koriste AcAIA
          </p>
          <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
            Započnite Besplatnu Probnu Verziju
          </Button>
        </div>
      </section>
    </div>
  );
} 